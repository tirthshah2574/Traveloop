import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useLocation, useParams } from "wouter";
import { useApp } from "@/contexts/AppContext";
import { useState, useEffect } from "react";
import { Compass, ArrowLeft, Plus, Search } from "lucide-react";
import { toast } from "sonner";
import { motion } from "framer-motion";

const SAMPLE_ACTIVITIES = [
  { name: "Eiffel Tower Tour", category: "Sightseeing", cost: 25, duration: 3 },
  { name: "French Cooking Class", category: "Food", cost: 80, duration: 4 },
  { name: "Seine River Cruise", category: "Sightseeing", cost: 20, duration: 2 },
  { name: "Louvre Museum", category: "Culture", cost: 18, duration: 3 },
  { name: "Street Food Tour", category: "Food", cost: 45, duration: 2.5 },
  { name: "Bike Tour", category: "Adventure", cost: 30, duration: 3 },
];

export default function ActivitySearch() {
  const [, navigate] = useLocation();
  const { id } = useParams<{ id: string }>();
  const { user, currentTrip, setCurrentTrip, trips, addActivity } = useApp();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [selectedDate, setSelectedDate] = useState("");
  const [activities, setActivities] = useState(SAMPLE_ACTIVITIES);

  useEffect(() => {
    if (!user) {
      navigate("/login");
      return;
    }
    if (!currentTrip) {
      const trip = trips.find(t => t.id === id);
      if (trip) {
        setCurrentTrip(trip);
        if (!selectedDate && trip.startDate) {
          setSelectedDate(trip.startDate);
        }
      }
    }
  }, [id, trips, user, navigate, currentTrip, setCurrentTrip, selectedDate]);

  const categories = ["All", ...Array.from(new Set(SAMPLE_ACTIVITIES.map(a => a.category)))];
  const filtered = activities.filter(activity => {
    const matchesSearch = activity.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "All" || activity.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleAddActivity = (activity: typeof SAMPLE_ACTIVITIES[0]) => {
    if (!selectedDate) {
      toast.error("Please select a date");
      return;
    }
    if (currentTrip) {
      addActivity(currentTrip.id, {
        city: currentTrip.destinations[0] || "Unknown",
        name: activity.name,
        description: `${activity.category} activity`,
        date: selectedDate,
        duration: activity.duration,
        cost: activity.cost,
        category: activity.category,
      });
      toast.success(`${activity.name} added to your trip!`);
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  };

  if (!currentTrip) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-900 to-slate-900 flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity }}
          className="w-8 h-8 border-4 border-orange-500 border-t-transparent rounded-full"
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-900 to-slate-900 text-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-slate-950/80 backdrop-blur-xl border-b border-slate-800">
        <div className="container flex items-center justify-between h-16">
          <motion.div
            className="flex items-center gap-2"
            whileHover={{ scale: 1.05 }}
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            >
              <Compass className="w-6 h-6 text-orange-500" />
            </motion.div>
            <span className="text-xl font-bold bg-gradient-to-r from-orange-500 to-pink-500 bg-clip-text text-transparent">
              Traveloop
            </span>
          </motion.div>
        </div>
      </nav>

      {/* Main Content */}
      <motion.div
        className="container py-12"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.button
          onClick={() => navigate("/my-trips")}
          className="flex items-center gap-2 text-orange-500 hover:text-orange-400 mb-8 font-medium transition-colors"
          whileHover={{ x: -5 }}
        >
          <ArrowLeft className="w-5 h-5" />
          Back to My Trips
        </motion.button>

        <div className="max-w-4xl">
          <motion.div variants={itemVariants}>
            <h1 className="text-5xl font-bold text-white mb-2">Discover Activities</h1>
            <p className="text-slate-400">
              Browse and add activities to your trip to {currentTrip.destinations[0] || "your destination"}
            </p>
          </motion.div>

          <motion.div
            className="mt-8 bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl shadow-2xl border border-slate-700 p-8 backdrop-blur-xl"
            variants={itemVariants}
          >
            {/* Filters */}
            <motion.div className="space-y-4 mb-6" variants={containerVariants}>
              <motion.div variants={itemVariants}>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Select Date
                </label>
                <Input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  min={currentTrip.startDate}
                  max={currentTrip.endDate}
                  className="bg-slate-700/50 border-slate-600 text-white focus:border-orange-500 focus:ring-orange-500/20"
                />
              </motion.div>

              <motion.div variants={itemVariants}>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Search Activities
                </label>
                <div className="relative">
                  <Search className="absolute left-3 top-3 w-5 h-5 text-slate-500" />
                  <Input
                    type="text"
                    placeholder="Search by name..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 bg-slate-700/50 border-slate-600 text-white placeholder-slate-500 focus:border-orange-500 focus:ring-orange-500/20"
                  />
                </div>
              </motion.div>

              <motion.div variants={itemVariants}>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Category
                </label>
                <div className="flex flex-wrap gap-2">
                  {categories.map(cat => (
                    <motion.button
                      key={cat}
                      onClick={() => setSelectedCategory(cat)}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                        selectedCategory === cat
                          ? "bg-gradient-to-r from-orange-500 to-pink-500 text-white"
                          : "bg-slate-700/50 text-slate-300 hover:bg-slate-700"
                      }`}
                    >
                      {cat}
                    </motion.button>
                  ))}
                </div>
              </motion.div>
            </motion.div>

            {/* Activities List */}
            <motion.div className="space-y-4" variants={containerVariants}>
              {filtered.length === 0 ? (
                <motion.div
                  className="text-center py-8 text-slate-500"
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 3, repeat: Infinity }}
                >
                  <Search className="w-12 h-12 mx-auto mb-2 opacity-50" />
                  <p>No activities found</p>
                </motion.div>
              ) : (
                filtered.map((activity, index) => (
                  <motion.div
                    key={index}
                    variants={itemVariants}
                    whileHover={{ x: 8 }}
                    className="flex items-start justify-between bg-slate-700/50 p-4 rounded-lg border border-slate-600 hover:border-slate-500 transition-colors"
                  >
                    <div className="flex-1">
                      <h3 className="font-semibold text-white">{activity.name}</h3>
                      <div className="flex flex-wrap gap-4 mt-2 text-sm">
                        <span className="px-2 py-1 bg-orange-500/20 text-orange-300 rounded text-xs font-medium">
                          {activity.category}
                        </span>
                        <span className="text-slate-400">${activity.cost}</span>
                        <span className="text-slate-400">{activity.duration} hours</span>
                      </div>
                    </div>
                    <motion.div
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="ml-4"
                    >
                      <Button
                        size="sm"
                        onClick={() => handleAddActivity(activity)}
                        className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white flex items-center gap-2"
                      >
                        <Plus className="w-4 h-4" />
                        Add
                      </Button>
                    </motion.div>
                  </motion.div>
                ))
              )}
            </motion.div>
          </motion.div>

          {/* Navigation */}
          <motion.div className="mt-8 flex gap-4" variants={itemVariants}>
            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="flex-1"
            >
              <Button
                onClick={() => navigate(`/trip/${currentTrip.id}/itinerary`)}
                className="w-full bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white font-semibold py-3 rounded-lg"
              >
                View Itinerary
              </Button>
            </motion.div>
            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="flex-1"
            >
              <Button
                variant="outline"
                onClick={() => navigate("/my-trips")}
                className="w-full border-slate-600 text-white hover:bg-slate-800 font-semibold py-3 rounded-lg"
              >
                Done
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}
