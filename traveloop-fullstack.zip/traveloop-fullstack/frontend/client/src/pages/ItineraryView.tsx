import { Button } from "@/components/ui/button";
import { useLocation, useParams } from "wouter";
import { useApp } from "@/contexts/AppContext";
import { useEffect, useState } from "react";
import { Compass, ArrowLeft, Calendar, MapPin, Clock, DollarSign, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { motion } from "framer-motion";

export default function ItineraryView() {
  const [, navigate] = useLocation();
  const { id } = useParams<{ id: string }>();
  const { user, trips, setCurrentTrip, currentTrip, deleteActivity } = useApp();

  useEffect(() => {
    if (!user) {
      navigate("/login");
      return;
    }
    const trip = trips.find(t => t.id === id);
    if (trip) {
      setCurrentTrip(trip);
    }
  }, [id, trips, user, navigate, setCurrentTrip]);

  const handleDeleteActivity = (activityId: string, name: string) => {
    if (window.confirm(`Remove "${name}" from your itinerary?`)) {
      if (currentTrip) {
        deleteActivity(currentTrip.id, activityId);
        toast.success("Activity removed");
      }
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  };

  if (!currentTrip) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-900 to-slate-900 flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity }}
          className="w-8 h-8 border-4 border-orange-500 border-t-transparent rounded-full"
        />
      </div>
    );
  }

  const activitiesByDate = currentTrip.activities.reduce((acc, activity) => {
    if (!acc[activity.date]) acc[activity.date] = [];
    acc[activity.date].push(activity);
    return acc;
  }, {} as Record<string, typeof currentTrip.activities>);

  const sortedDates = Object.keys(activitiesByDate).sort();
  const totalCost = currentTrip.activities.reduce((sum, a) => sum + a.cost, 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-900 to-slate-900 text-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-slate-950/80 backdrop-blur-xl border-b border-slate-800">
        <div className="container flex items-center justify-between h-16">
          <motion.div
            className="flex items-center gap-2"
            whileHover={{ scale: 1.05 }}
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            >
              <Compass className="w-6 h-6 text-orange-500" />
            </motion.div>
            <span className="text-xl font-bold bg-gradient-to-r from-orange-500 to-pink-500 bg-clip-text text-transparent">
              Traveloop
            </span>
          </motion.div>
        </div>
      </nav>

      {/* Main Content */}
      <motion.div
        className="container py-12"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.button
          onClick={() => navigate("/my-trips")}
          className="flex items-center gap-2 text-orange-500 hover:text-orange-400 mb-8 font-medium transition-colors"
          whileHover={{ x: -5 }}
        >
          <ArrowLeft className="w-5 h-5" />
          Back to My Trips
        </motion.button>

        <div className="max-w-4xl">
          <motion.div variants={itemVariants}>
            <h1 className="text-5xl font-bold text-white mb-2">{currentTrip.name}</h1>
            <div className="flex flex-wrap gap-6 text-slate-400">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-orange-500" />
                {new Date(currentTrip.startDate).toLocaleDateString()} - {new Date(currentTrip.endDate).toLocaleDateString()}
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-orange-500" />
                {currentTrip.destinations.length} destinations
              </div>
            </div>
          </motion.div>

          {/* Summary Cards */}
          <motion.div
            className="mt-8 grid md:grid-cols-3 gap-4"
            variants={containerVariants}
          >
            <motion.div
              variants={itemVariants}
              className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-xl p-6 border border-slate-700 shadow-lg"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-400 text-sm">Total Activities</p>
                  <p className="text-3xl font-bold text-white mt-1">{currentTrip.activities.length}</p>
                </div>
                <div className="w-12 h-12 bg-orange-500/20 rounded-lg flex items-center justify-center">
                  <Clock className="w-6 h-6 text-orange-500" />
                </div>
              </div>
            </motion.div>

            <motion.div
              variants={itemVariants}
              className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-xl p-6 border border-slate-700 shadow-lg"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-400 text-sm">Total Cost</p>
                  <p className="text-3xl font-bold text-white mt-1">${totalCost}</p>
                </div>
                <div className="w-12 h-12 bg-pink-500/20 rounded-lg flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-pink-500" />
                </div>
              </div>
            </motion.div>

            <motion.div
              variants={itemVariants}
              className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-xl p-6 border border-slate-700 shadow-lg"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-400 text-sm">Destinations</p>
                  <p className="text-3xl font-bold text-white mt-1">{currentTrip.destinations.length}</p>
                </div>
                <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
                  <MapPin className="w-6 h-6 text-blue-500" />
                </div>
              </div>
            </motion.div>
          </motion.div>

          {/* Itinerary */}
          {sortedDates.length === 0 ? (
            <motion.div
              className="mt-8 bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-16 text-center border border-slate-700"
              variants={itemVariants}
            >
              <p className="text-slate-400 mb-4">No activities planned yet</p>
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  onClick={() => navigate(`/trip/${currentTrip.id}/activities`)}
                  className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white"
                >
                  Add Activities
                </Button>
              </motion.div>
            </motion.div>
          ) : (
            <motion.div className="mt-8 space-y-6" variants={containerVariants}>
              {sortedDates.map((date) => (
                <motion.div key={date} variants={itemVariants}>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-pink-500 rounded-lg flex items-center justify-center">
                      <Calendar className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white">
                        {new Date(date).toLocaleDateString("en-US", {
                          weekday: "long",
                          month: "long",
                          day: "numeric",
                        })}
                      </h3>
                      <p className="text-sm text-slate-400">
                        {activitiesByDate[date].length} activity
                        {activitiesByDate[date].length !== 1 ? "ies" : ""}
                      </p>
                    </div>
                  </div>

                  <motion.div
                    className="space-y-3 ml-6 border-l-2 border-slate-700 pl-6"
                    variants={containerVariants}
                  >
                    {activitiesByDate[date].map((activity) => (
                      <motion.div
                        key={activity.id}
                        variants={itemVariants}
                        whileHover={{ x: 8 }}
                        className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-lg p-4 border border-slate-700 hover:border-slate-600 transition-colors"
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h4 className="font-semibold text-white">{activity.name}</h4>
                            <p className="text-sm text-slate-400 mt-1">{activity.description}</p>
                            <div className="flex flex-wrap gap-4 mt-3 text-sm">
                              <span className="px-2 py-1 bg-orange-500/20 text-orange-300 rounded text-xs font-medium">
                                {activity.category}
                              </span>
                              <div className="flex items-center gap-1 text-slate-400">
                                <Clock className="w-4 h-4" />
                                {activity.duration} hours
                              </div>
                              <div className="flex items-center gap-1 text-slate-400">
                                <DollarSign className="w-4 h-4" />
                                ${activity.cost}
                              </div>
                            </div>
                          </div>
                          <motion.div
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.95 }}
                          >
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleDeleteActivity(activity.id, activity.name)}
                              className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </motion.div>
                        </div>
                      </motion.div>
                    ))}
                  </motion.div>
                </motion.div>
              ))}
            </motion.div>
          )}

          {/* Navigation */}
          <motion.div className="mt-12 flex gap-4" variants={itemVariants}>
            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="flex-1"
            >
              <Button
                onClick={() => navigate(`/trip/${currentTrip.id}/budget`)}
                className="w-full bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white font-semibold py-3 rounded-lg"
              >
                View Budget
              </Button>
            </motion.div>
            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="flex-1"
            >
              <Button
                onClick={() => navigate(`/trip/${currentTrip.id}/packing`)}
                className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white font-semibold py-3 rounded-lg"
              >
                Packing List
              </Button>
            </motion.div>
            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="flex-1"
            >
              <Button
                variant="outline"
                onClick={() => navigate("/my-trips")}
                className="w-full border-slate-600 text-white hover:bg-slate-800 font-semibold py-3 rounded-lg"
              >
                Back
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}
