import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useApp } from "@/contexts/AppContext";
import { Compass, Plus, MapPin, Calendar, Users, Trash2, MoreVertical } from "lucide-react";
import { toast } from "sonner";
import { motion } from "framer-motion";
import { useState } from "react";

export default function MyTrips() {
  const [, navigate] = useLocation();
  const { user, trips, deleteTrip } = useApp();
  const [hoveredTrip, setHoveredTrip] = useState<string | null>(null);
  const [openMenu, setOpenMenu] = useState<string | null>(null);

  if (!user) {
    navigate("/login");
    return null;
  }

  const handleDelete = (id: string, name: string) => {
    if (window.confirm(`Are you sure you want to delete "${name}"?`)) {
      deleteTrip(id);
      toast.success("Trip deleted");
      setOpenMenu(null);
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-900 to-slate-900 text-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-slate-950/80 backdrop-blur-xl border-b border-slate-800">
        <div className="container flex items-center justify-between h-16">
          <motion.div
            className="flex items-center gap-2"
            whileHover={{ scale: 1.05 }}
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            >
              <Compass className="w-6 h-6 text-orange-500" />
            </motion.div>
            <span className="text-xl font-bold bg-gradient-to-r from-orange-500 to-pink-500 bg-clip-text text-transparent">
              Traveloop
            </span>
          </motion.div>
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button
              onClick={() => navigate("/dashboard")}
              variant="ghost"
              className="text-slate-300 hover:text-white hover:bg-slate-800"
            >
              Dashboard
            </Button>
          </motion.div>
        </div>
      </nav>

      {/* Main Content */}
      <motion.div
        className="container py-12"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Header */}
        <motion.div
          className="flex items-center justify-between mb-12"
          variants={itemVariants}
        >
          <div>
            <h1 className="text-5xl font-bold text-white mb-2">My Trips</h1>
            <p className="text-slate-400">
              {trips.length} {trips.length === 1 ? "trip" : "trips"} planned
            </p>
          </div>
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button
              onClick={() => navigate("/create-trip")}
              className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white flex items-center gap-2 text-base px-6"
            >
              <Plus className="w-5 h-5" />
              New Trip
            </Button>
          </motion.div>
        </motion.div>

        {/* Trips Grid */}
        {trips.length === 0 ? (
          <motion.div
            className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-16 text-center border border-slate-700"
            whileHover={{ borderColor: "rgb(148, 163, 184)" }}
            variants={itemVariants}
          >
            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 3, repeat: Infinity }}
            >
              <MapPin className="w-16 h-16 text-slate-600 mx-auto mb-4" />
            </motion.div>
            <h3 className="text-lg font-semibold text-white mb-2">
              No trips yet
            </h3>
            <p className="text-slate-400 mb-6">
              Start planning your first adventure today!
            </p>
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button
                onClick={() => navigate("/create-trip")}
                className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white"
              >
                Create Your First Trip
              </Button>
            </motion.div>
          </motion.div>
        ) : (
          <motion.div
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
            variants={containerVariants}
          >
            {trips.map((trip) => {
              const startDate = new Date(trip.startDate);
              const endDate = new Date(trip.endDate);
              const daysLeft = Math.ceil(
                (startDate.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)
              );
              const isUpcoming = daysLeft > 0;

              return (
                <motion.div
                  key={trip.id}
                  variants={itemVariants}
                  onMouseEnter={() => setHoveredTrip(trip.id)}
                  onMouseLeave={() => setHoveredTrip(null)}
                  whileHover={{ y: -8 }}
                  className="group relative"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-orange-500 to-pink-500 rounded-2xl opacity-0 group-hover:opacity-20 blur-xl transition-opacity duration-300" />
                  <div className="relative bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl overflow-hidden shadow-xl border border-slate-700 hover:border-slate-600 transition-colors h-full flex flex-col">
                    {/* Header Image */}
                    <div className="h-32 bg-gradient-to-br from-orange-400 via-pink-400 to-blue-400 relative overflow-hidden">
                      <motion.div
                        className="absolute inset-0 opacity-30"
                        animate={{
                          backgroundPosition: ["0% 0%", "100% 100%"],
                        }}
                        transition={{ duration: 20, repeat: Infinity }}
                      />
                      {isUpcoming && (
                        <div className="absolute top-3 right-3 px-3 py-1 bg-green-500/90 rounded-full text-xs font-semibold">
                          {daysLeft} days left
                        </div>
                      )}
                    </div>

                    {/* Content */}
                    <div className="p-6 flex-1 flex flex-col">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold text-white mb-1">
                            {trip.name}
                          </h3>
                          <p className="text-slate-400 text-sm line-clamp-1">
                            {trip.description || "No description"}
                          </p>
                        </div>
                        <motion.button
                          onClick={() => setOpenMenu(openMenu === trip.id ? null : trip.id)}
                          className="text-slate-400 hover:text-white p-1"
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          <MoreVertical className="w-5 h-5" />
                        </motion.button>
                      </div>

                      {/* Menu */}
                      {openMenu === trip.id && (
                        <motion.div
                          initial={{ opacity: 0, y: -10 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="absolute top-12 right-3 bg-slate-800 rounded-lg shadow-lg border border-slate-700 overflow-hidden z-10"
                        >
                          <button
                            onClick={() => {
                              navigate(`/trip/${trip.id}/builder`);
                              setOpenMenu(null);
                            }}
                            className="w-full px-4 py-2 text-left text-sm text-slate-300 hover:bg-slate-700 hover:text-white transition-colors"
                          >
                            Edit
                          </button>
                          <button
                            onClick={() => handleDelete(trip.id, trip.name)}
                            className="w-full px-4 py-2 text-left text-sm text-red-400 hover:bg-red-500/10 transition-colors"
                          >
                            Delete
                          </button>
                        </motion.div>
                      )}

                      {/* Info */}
                      <div className="space-y-2 mb-4 flex-1">
                        <div className="flex items-center gap-2 text-sm text-slate-400">
                          <Calendar className="w-4 h-4 text-orange-500" />
                          {startDate.toLocaleDateString()} - {endDate.toLocaleDateString()}
                        </div>
                        <div className="flex items-center gap-2 text-sm text-slate-400">
                          <MapPin className="w-4 h-4 text-orange-500" />
                          {trip.destinations.length} destination
                          {trip.destinations.length !== 1 ? "s" : ""}
                        </div>
                        <div className="flex items-center gap-2 text-sm text-slate-400">
                          <Users className="w-4 h-4 text-orange-500" />
                          {trip.activities.length} activities
                        </div>
                      </div>

                      {/* Actions */}
                      <motion.div
                        className="flex gap-2"
                        initial={{ opacity: 0 }}
                        animate={{
                          opacity: hoveredTrip === trip.id ? 1 : 0,
                        }}
                      >
                        <motion.div
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          className="flex-1"
                        >
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => navigate(`/trip/${trip.id}/builder`)}
                            className="w-full border-slate-600 text-white hover:bg-slate-800"
                          >
                            Edit
                          </Button>
                        </motion.div>
                        <motion.div
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          className="flex-1"
                        >
                          <Button
                            size="sm"
                            onClick={() => navigate(`/trip/${trip.id}/itinerary`)}
                            className="w-full bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white"
                          >
                            View
                          </Button>
                        </motion.div>
                      </motion.div>
                      <motion.div
                        className="flex gap-2"
                        initial={{ opacity: 1 }}
                        animate={{
                          opacity: hoveredTrip === trip.id ? 0 : 1,
                        }}
                      >
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => navigate(`/trip/${trip.id}/builder`)}
                          className="flex-1 border-slate-600 text-white hover:bg-slate-800"
                        >
                          Edit
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => navigate(`/trip/${trip.id}/itinerary`)}
                          className="flex-1 bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white"
                        >
                          View
                        </Button>
                      </motion.div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </motion.div>
        )}
      </motion.div>
    </div>
  );
}
