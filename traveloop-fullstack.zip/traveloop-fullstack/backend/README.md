# Traveloop Backend (Node.js + Express + MySQL)

REST API powering the Traveloop travel-planning app.

## Quick start

```bash
# 1. Install deps
npm install

# 2. Configure env
cp .env.example .env
#   then edit .env (DB credentials, JWT_SECRET, CORS_ORIGIN)

# 3. Create the database & tables
npm run migrate

# 4. (optional) seed cities catalog
npm run seed

# 5. Run
npm run dev      # nodemon, http://localhost:4000
# or
npm start
```

Make sure MySQL 8+ is running locally (or point `DB_HOST`/`DB_PORT` at any
managed MySQL such as PlanetScale, Railway, AWS RDS).

## API overview

All authenticated endpoints expect `Authorization: Bearer <jwt>`.

### Auth
- `POST   /api/auth/signup`            `{ email, password, name }`
- `POST   /api/auth/login`             `{ email, password }`
- `GET    /api/auth/me`
- `PATCH  /api/auth/me`                `{ name?, photoUrl?, language? }`
- `DELETE /api/auth/me`

### Trips
- `GET    /api/trips`                  list current user's trips
- `POST   /api/trips`                  create
- `GET    /api/trips/:id`              full trip (stops + activities + packing + notes)
- `PATCH  /api/trips/:id`
- `DELETE /api/trips/:id`
- `POST   /api/trips/:id/share`        `{ isPublic: true|false }` → `{ publicSlug }`
- `GET    /api/trips/:id/budget`       cost breakdown by category & day

### Stops (cities inside a trip)
- `GET    /api/trips/:tripId/stops`
- `POST   /api/trips/:tripId/stops`
- `POST   /api/trips/:tripId/stops/reorder`  `{ order: [stopId, ...] }`
- `PATCH  /api/trips/:tripId/stops/:stopId`
- `DELETE /api/trips/:tripId/stops/:stopId`

### Activities
- `GET    /api/trips/:tripId/activities`
- `POST   /api/trips/:tripId/activities`
- `PATCH  /api/trips/:tripId/activities/:activityId`
- `DELETE /api/trips/:tripId/activities/:activityId`
- `GET    /api/activities/search?q=&city=&category=&maxCost=`  (catalog suggestions)

### Packing checklist
- `GET    /api/trips/:tripId/packing`
- `POST   /api/trips/:tripId/packing`
- `POST   /api/trips/:tripId/packing/reset`
- `PATCH  /api/trips/:tripId/packing/:itemId`
- `DELETE /api/trips/:tripId/packing/:itemId`

### Notes / Journal
- `GET    /api/trips/:tripId/notes`
- `POST   /api/trips/:tripId/notes`
- `PATCH  /api/trips/:tripId/notes/:noteId`
- `DELETE /api/trips/:tripId/notes/:noteId`

### City search
- `GET    /api/cities/search?q=&country=&limit=`
- `GET    /api/cities/popular`
- `GET    /api/cities/saved`               (auth)
- `POST   /api/cities/saved/:cityId`       (auth)
- `DELETE /api/cities/saved/:cityId`       (auth)

### Public / shared itineraries
- `GET    /api/public/trips/:slug`             read-only
- `POST   /api/public/trips/:slug/copy`        (auth) duplicate into your account

### Admin / analytics (optional)
- `GET    /api/admin/stats`   (add real RBAC before exposing)

## Wiring it to the existing frontend

Your frontend's `AppContext` currently uses `localStorage`. Replace each
operation with a `fetch('http://localhost:4000/api/...')` call and store the
JWT returned by `/api/auth/login` (e.g. in `localStorage` as `traveloop_token`).
Send it on every request as `Authorization: Bearer <token>`.

## Schema

See `src/db/schema.sql` — tables: `users`, `cities`, `trips`, `trip_stops`,
`activities`, `packing_items`, `trip_notes`, `saved_destinations`. All
`ON DELETE CASCADE` from `trips`/`users` so cleanup is automatic.

## Stack
Express 4 · mysql2 · JWT (jsonwebtoken) · bcryptjs · zod validation ·
helmet · cors · morgan · express-rate-limit.
