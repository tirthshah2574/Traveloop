import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useApp } from "@/contexts/AppContext";
import { MapPin, Compass, DollarSign, Users, ArrowRight, Sparkles, Globe } from "lucide-react";
import { motion } from "framer-motion";
import { useState, useEffect } from "react";

const FloatingCard = ({ delay, children }: { delay: number; children: React.ReactNode }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    transition={{ delay, duration: 0.6 }}
    viewport={{ once: true }}
  >
    {children}
  </motion.div>
);

export default function Home() {
  const [, navigate] = useLocation();
  const { user } = useApp();
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  const features = [
    {
      icon: MapPin,
      title: "Multi-City Planning",
      description: "Add multiple destinations and organize your journey seamlessly.",
      color: "from-orange-500 to-red-500",
    },
    {
      icon: Compass,
      title: "Activity Discovery",
      description: "Explore activities, restaurants, and attractions at each stop.",
      color: "from-blue-500 to-cyan-500",
    },
    {
      icon: DollarSign,
      title: "Budget Tracking",
      description: "Monitor expenses and stay within your budget with detailed breakdowns.",
      color: "from-green-500 to-emerald-500",
    },
    {
      icon: Users,
      title: "Share & Collaborate",
      description: "Share your plans with friends and plan together.",
      color: "from-purple-500 to-pink-500",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-900 to-slate-900 text-white overflow-hidden">
      {/* Animated Background Elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <motion.div
          className="absolute w-96 h-96 bg-orange-500 rounded-full opacity-10 blur-3xl"
          animate={{
            x: mousePosition.x - 192,
            y: mousePosition.y - 192,
          }}
          transition={{ type: "spring", damping: 30, stiffness: 200 }}
        />
        <motion.div
          className="absolute top-1/4 right-1/4 w-72 h-72 bg-blue-500 rounded-full opacity-10 blur-3xl"
          animate={{
            x: -mousePosition.x / 10,
            y: -mousePosition.y / 10,
          }}
          transition={{ type: "spring", damping: 30, stiffness: 200 }}
        />
      </div>

      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-slate-950/80 backdrop-blur-xl border-b border-slate-800">
        <div className="container flex items-center justify-between h-16">
          <motion.div
            className="flex items-center gap-2"
            whileHover={{ scale: 1.05 }}
            transition={{ type: "spring", stiffness: 400, damping: 10 }}
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            >
              <Compass className="w-6 h-6 text-orange-500" />
            </motion.div>
            <span className="text-xl font-bold bg-gradient-to-r from-orange-500 to-pink-500 bg-clip-text text-transparent">
              Traveloop
            </span>
          </motion.div>
          <div className="flex items-center gap-4">
            {user ? (
              <>
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    variant="ghost"
                    onClick={() => navigate("/dashboard")}
                    className="text-slate-300 hover:text-white hover:bg-slate-800"
                  >
                    Dashboard
                  </Button>
                </motion.div>
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    onClick={() => navigate("/my-trips")}
                    className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white border-0"
                  >
                    My Trips
                  </Button>
                </motion.div>
              </>
            ) : (
              <>
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    variant="ghost"
                    onClick={() => navigate("/login")}
                    className="text-slate-300 hover:text-white hover:bg-slate-800"
                  >
                    Login
                  </Button>
                </motion.div>
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    onClick={() => navigate("/signup")}
                    className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white border-0"
                  >
                    Sign Up
                  </Button>
                </motion.div>
              </>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container relative py-20 md:py-32">
        <div className="max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <motion.div
              className="inline-flex items-center gap-2 mb-6 px-4 py-2 bg-slate-800/50 rounded-full border border-slate-700 backdrop-blur-sm"
              whileHover={{ scale: 1.05, backgroundColor: "rgba(30, 41, 59, 0.8)" }}
            >
              <Sparkles className="w-4 h-4 text-orange-500" />
              <span className="text-sm text-slate-300">Welcome to the future of travel planning</span>
            </motion.div>

            <h1 className="text-6xl md:text-7xl font-bold mb-6 leading-tight">
              <span className="bg-gradient-to-r from-orange-400 via-pink-400 to-purple-400 bg-clip-text text-transparent">
                Plan Your Perfect
              </span>
              <br />
              <span className="text-white">Trip Effortlessly</span>
            </h1>
          </motion.div>

          <motion.p
            className="text-xl text-slate-300 mb-8 leading-relaxed max-w-2xl"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            Create personalized itineraries, track budgets, discover activities, and share your adventures with friends. All in one beautiful, intuitive platform.
          </motion.p>

          <motion.div
            className="flex flex-col sm:flex-row gap-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            {user ? (
              <>
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    size="lg"
                    onClick={() => navigate("/create-trip")}
                    className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white border-0 text-base px-8"
                  >
                    Plan New Trip
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </motion.div>
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    size="lg"
                    variant="outline"
                    onClick={() => navigate("/my-trips")}
                    className="border-slate-600 text-white hover:bg-slate-800 text-base px-8"
                  >
                    View My Trips
                  </Button>
                </motion.div>
              </>
            ) : (
              <>
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    size="lg"
                    onClick={() => navigate("/signup")}
                    className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white border-0 text-base px-8"
                  >
                    Get Started
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </motion.div>
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    size="lg"
                    variant="outline"
                    onClick={() => navigate("/login")}
                    className="border-slate-600 text-white hover:bg-slate-800 text-base px-8"
                  >
                    Sign In
                  </Button>
                </motion.div>
              </>
            )}
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container py-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl font-bold mb-4">Everything You Need</h2>
          <p className="text-xl text-slate-400">
            Powerful features designed for modern travelers
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <FloatingCard key={index} delay={index * 0.1}>
                <motion.div
                  className="group relative bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-8 border border-slate-700 hover:border-slate-600 overflow-hidden cursor-pointer"
                  whileHover={{ y: -8, borderColor: "rgb(148, 163, 184)" }}
                  transition={{ type: "spring", stiffness: 300, damping: 10 }}
                >
                  <div className={`absolute inset-0 bg-gradient-to-br ${feature.color} opacity-0 group-hover:opacity-10 transition-opacity duration-300`} />

                  <motion.div
                    className={`w-12 h-12 rounded-xl bg-gradient-to-br ${feature.color} p-2.5 mb-4 relative z-10`}
                    whileHover={{ scale: 1.1, rotate: 5 }}
                  >
                    <Icon className="w-full h-full text-white" />
                  </motion.div>

                  <h3 className="text-lg font-semibold text-white mb-2 relative z-10">
                    {feature.title}
                  </h3>
                  <p className="text-slate-400 relative z-10">
                    {feature.description}
                  </p>
                </motion.div>
              </FloatingCard>
            );
          })}
        </div>
      </section>

      {/* Stats Section */}
      <section className="container py-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="bg-gradient-to-r from-orange-600/20 to-pink-600/20 rounded-3xl border border-slate-700 p-12 md:p-16 backdrop-blur-sm"
        >
          <div className="grid md:grid-cols-3 gap-8 text-center">
            {[
              { number: "10K+", label: "Travelers" },
              { number: "50K+", label: "Trips Planned" },
              { number: "100K+", label: "Activities" },
            ].map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                viewport={{ once: true }}
              >
                <motion.div
                  className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-orange-400 to-pink-400 bg-clip-text text-transparent mb-2"
                  whileInView={{ scale: [1, 1.1, 1] }}
                  transition={{ delay: index * 0.1 + 0.3, duration: 0.6 }}
                  viewport={{ once: true }}
                >
                  {stat.number}
                </motion.div>
                <div className="text-slate-300">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* CTA Section */}
      <section className="container py-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="relative overflow-hidden rounded-3xl p-12 md:p-20 text-center"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-orange-600 to-pink-600 opacity-20 blur-3xl" />
          <div className="relative z-10">
            <motion.h2
              className="text-5xl md:text-6xl font-bold mb-6"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              Ready to Start Your
              <br />
              <span className="bg-gradient-to-r from-orange-400 to-pink-400 bg-clip-text text-transparent">
                Adventure?
              </span>
            </motion.h2>

            <motion.p
              className="text-lg text-slate-300 mb-8 max-w-2xl mx-auto"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              viewport={{ once: true }}
            >
              Join thousands of travelers planning their perfect trips with Traveloop.
            </motion.p>

            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              viewport={{ once: true }}
            >
              <Button
                size="lg"
                onClick={() => navigate(user ? "/create-trip" : "/signup")}
                className="bg-white text-orange-600 hover:bg-slate-100 text-base px-8 font-semibold"
              >
                {user ? "Create Your First Trip" : "Sign Up Now"}
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </motion.div>
          </div>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-800 bg-slate-950/50 backdrop-blur-sm mt-20">
        <div className="container py-12">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <motion.div
              className="flex items-center gap-2 mb-4 md:mb-0"
              whileHover={{ scale: 1.05 }}
            >
              <Compass className="w-6 h-6 text-orange-500" />
              <span className="text-lg font-bold bg-gradient-to-r from-orange-500 to-pink-500 bg-clip-text text-transparent">
                Traveloop
              </span>
            </motion.div>
            <p className="text-slate-400 text-sm">
              © 2026 Traveloop. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
