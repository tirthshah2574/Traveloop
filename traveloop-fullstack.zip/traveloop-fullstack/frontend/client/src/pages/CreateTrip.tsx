import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";
import { useApp } from "@/contexts/AppContext";
import { useState } from "react";
import { Compass, ArrowLeft, MapPin, Calendar, DollarSign } from "lucide-react";
import { toast } from "sonner";
import { motion } from "framer-motion";

export default function CreateTrip() {
  const [, navigate] = useLocation();
  const { user, createTrip } = useApp();
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [budget, setBudget] = useState("");
  const [focusedField, setFocusedField] = useState<string | null>(null);

  if (!user) {
    navigate("/login");
    return null;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !startDate || !endDate) {
      toast.error("Please fill in required fields");
      return;
    }
    if (new Date(startDate) >= new Date(endDate)) {
      toast.error("End date must be after start date");
      return;
    }

    createTrip({
      name,
      description,
      startDate,
      endDate,
      destinations: [],
      budget: budget ? parseFloat(budget) : 0,
    });
    toast.success("Trip created successfully!");
    navigate("/my-trips");
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-900 to-slate-900 text-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-slate-950/80 backdrop-blur-xl border-b border-slate-800">
        <div className="container flex items-center justify-between h-16">
          <motion.div
            className="flex items-center gap-2"
            whileHover={{ scale: 1.05 }}
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            >
              <Compass className="w-6 h-6 text-orange-500" />
            </motion.div>
            <span className="text-xl font-bold bg-gradient-to-r from-orange-500 to-pink-500 bg-clip-text text-transparent">
              Traveloop
            </span>
          </motion.div>
        </div>
      </nav>

      {/* Main Content */}
      <motion.div
        className="container py-12"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.button
          onClick={() => navigate("/dashboard")}
          className="flex items-center gap-2 text-orange-500 hover:text-orange-400 mb-8 font-medium transition-colors"
          whileHover={{ x: -5 }}
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Dashboard
        </motion.button>

        <div className="max-w-2xl">
          <motion.div variants={itemVariants}>
            <h1 className="text-5xl font-bold text-white mb-2">Plan Your Trip</h1>
            <p className="text-slate-400">
              Let's start by creating a new trip. Fill in the basic information and we'll help you build the perfect itinerary.
            </p>
          </motion.div>

          <motion.div
            className="mt-8 bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl shadow-2xl border border-slate-700 p-8 backdrop-blur-xl"
            variants={itemVariants}
          >
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Trip Name */}
              <motion.div variants={itemVariants}>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Trip Name *
                </label>
                <motion.div
                  animate={{
                    boxShadow:
                      focusedField === "name"
                        ? "0 0 20px rgba(249, 115, 22, 0.3)"
                        : "0 0 0px rgba(0, 0, 0, 0)",
                  }}
                >
                  <Input
                    type="text"
                    placeholder="e.g., Summer Europe Adventure"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    onFocus={() => setFocusedField("name")}
                    onBlur={() => setFocusedField(null)}
                    className="bg-slate-700/50 border-slate-600 text-white placeholder-slate-500 focus:border-orange-500 focus:ring-orange-500/20"
                  />
                </motion.div>
              </motion.div>

              {/* Description */}
              <motion.div variants={itemVariants}>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Description
                </label>
                <motion.div
                  animate={{
                    boxShadow:
                      focusedField === "description"
                        ? "0 0 20px rgba(249, 115, 22, 0.3)"
                        : "0 0 0px rgba(0, 0, 0, 0)",
                  }}
                >
                  <textarea
                    placeholder="Tell us about your trip..."
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    onFocus={() => setFocusedField("description")}
                    onBlur={() => setFocusedField(null)}
                    className="w-full px-4 py-2 bg-slate-700/50 border border-slate-600 text-white placeholder-slate-500 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 resize-none"
                    rows={4}
                  />
                </motion.div>
              </motion.div>

              {/* Dates */}
              <motion.div variants={itemVariants} className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2 flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-orange-500" />
                    Start Date *
                  </label>
                  <motion.div
                    animate={{
                      boxShadow:
                        focusedField === "startDate"
                          ? "0 0 20px rgba(249, 115, 22, 0.3)"
                          : "0 0 0px rgba(0, 0, 0, 0)",
                    }}
                  >
                    <Input
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                      onFocus={() => setFocusedField("startDate")}
                      onBlur={() => setFocusedField(null)}
                      className="bg-slate-700/50 border-slate-600 text-white focus:border-orange-500 focus:ring-orange-500/20"
                    />
                  </motion.div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2 flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-orange-500" />
                    End Date *
                  </label>
                  <motion.div
                    animate={{
                      boxShadow:
                        focusedField === "endDate"
                          ? "0 0 20px rgba(249, 115, 22, 0.3)"
                          : "0 0 0px rgba(0, 0, 0, 0)",
                    }}
                  >
                    <Input
                      type="date"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                      onFocus={() => setFocusedField("endDate")}
                      onBlur={() => setFocusedField(null)}
                      className="bg-slate-700/50 border-slate-600 text-white focus:border-orange-500 focus:ring-orange-500/20"
                    />
                  </motion.div>
                </div>
              </motion.div>

              {/* Budget */}
              <motion.div variants={itemVariants}>
                <label className="block text-sm font-medium text-slate-300 mb-2 flex items-center gap-2">
                  <DollarSign className="w-4 h-4 text-orange-500" />
                  Budget (Optional)
                </label>
                <motion.div
                  animate={{
                    boxShadow:
                      focusedField === "budget"
                        ? "0 0 20px rgba(249, 115, 22, 0.3)"
                        : "0 0 0px rgba(0, 0, 0, 0)",
                  }}
                  className="relative"
                >
                  <span className="absolute left-4 top-3 text-slate-500">$</span>
                  <Input
                    type="number"
                    placeholder="0.00"
                    value={budget}
                    onChange={(e) => setBudget(e.target.value)}
                    onFocus={() => setFocusedField("budget")}
                    onBlur={() => setFocusedField(null)}
                    className="pl-8 bg-slate-700/50 border-slate-600 text-white placeholder-slate-500 focus:border-orange-500 focus:ring-orange-500/20"
                  />
                </motion.div>
              </motion.div>

              {/* Buttons */}
              <motion.div variants={itemVariants} className="flex gap-4 pt-4">
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="flex-1"
                >
                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white font-semibold py-3 rounded-lg"
                  >
                    Create Trip
                  </Button>
                </motion.div>
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="flex-1"
                >
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => navigate("/dashboard")}
                    className="w-full border-slate-600 text-white hover:bg-slate-800"
                  >
                    Cancel
                  </Button>
                </motion.div>
              </motion.div>
            </form>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}
