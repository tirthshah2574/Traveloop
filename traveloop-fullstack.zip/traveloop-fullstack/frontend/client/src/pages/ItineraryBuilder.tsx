import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useLocation, useParams } from "wouter";
import { useApp } from "@/contexts/AppContext";
import { useState, useEffect } from "react";
import { Compass, ArrowLeft, Plus, Trash2, MapPin } from "lucide-react";
import { toast } from "sonner";
import { motion } from "framer-motion";

export default function ItineraryBuilder() {
  const [, navigate] = useLocation();
  const { id } = useParams<{ id: string }>();
  const { user, trips, setCurrentTrip, currentTrip, updateTrip } = useApp();
  const [destinations, setDestinations] = useState<string[]>([]);
  const [newDestination, setNewDestination] = useState("");
  const [focusedField, setFocusedField] = useState(false);

  useEffect(() => {
    if (!user) {
      navigate("/login");
      return;
    }
    const trip = trips.find(t => t.id === id);
    if (trip) {
      setCurrentTrip(trip);
      setDestinations(trip.destinations);
    }
  }, [id, trips, user, navigate, setCurrentTrip]);

  const handleAddDestination = () => {
    if (!newDestination.trim()) {
      toast.error("Please enter a destination");
      return;
    }
    if (destinations.includes(newDestination)) {
      toast.error("This destination is already added");
      return;
    }
    const updated = [...destinations, newDestination];
    setDestinations(updated);
    setNewDestination("");
    if (currentTrip) {
      updateTrip(currentTrip.id, { destinations: updated });
    }
    toast.success("Destination added!");
  };

  const handleRemoveDestination = (index: number) => {
    const updated = destinations.filter((_, i) => i !== index);
    setDestinations(updated);
    if (currentTrip) {
      updateTrip(currentTrip.id, { destinations: updated });
    }
    toast.success("Destination removed");
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  };

  if (!currentTrip) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-900 to-slate-900 flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity }}
          className="w-8 h-8 border-4 border-orange-500 border-t-transparent rounded-full"
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-900 to-slate-900 text-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-slate-950/80 backdrop-blur-xl border-b border-slate-800">
        <div className="container flex items-center justify-between h-16">
          <motion.div
            className="flex items-center gap-2"
            whileHover={{ scale: 1.05 }}
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            >
              <Compass className="w-6 h-6 text-orange-500" />
            </motion.div>
            <span className="text-xl font-bold bg-gradient-to-r from-orange-500 to-pink-500 bg-clip-text text-transparent">
              Traveloop
            </span>
          </motion.div>
        </div>
      </nav>

      {/* Main Content */}
      <motion.div
        className="container py-12"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.button
          onClick={() => navigate("/my-trips")}
          className="flex items-center gap-2 text-orange-500 hover:text-orange-400 mb-8 font-medium transition-colors"
          whileHover={{ x: -5 }}
        >
          <ArrowLeft className="w-5 h-5" />
          Back to My Trips
        </motion.button>

        <div className="max-w-3xl">
          <motion.div variants={itemVariants}>
            <h1 className="text-5xl font-bold text-white mb-2">{currentTrip.name}</h1>
            <p className="text-slate-400">
              Add and manage the destinations for your trip
            </p>
          </motion.div>

          <motion.div
            className="mt-8 bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl shadow-2xl border border-slate-700 p-8 backdrop-blur-xl"
            variants={itemVariants}
          >
            {/* Add Destination */}
            <motion.div className="mb-8" variants={itemVariants}>
              <h2 className="text-lg font-semibold text-white mb-4">Add Destinations</h2>
              <div className="flex gap-2">
                <motion.div
                  className="flex-1"
                  animate={{
                    boxShadow: focusedField
                      ? "0 0 20px rgba(249, 115, 22, 0.3)"
                      : "0 0 0px rgba(0, 0, 0, 0)",
                  }}
                >
                  <Input
                    type="text"
                    placeholder="e.g., Paris, Tokyo, Barcelona"
                    value={newDestination}
                    onChange={(e) => setNewDestination(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && handleAddDestination()}
                    onFocus={() => setFocusedField(true)}
                    onBlur={() => setFocusedField(false)}
                    className="bg-slate-700/50 border-slate-600 text-white placeholder-slate-500 focus:border-orange-500 focus:ring-orange-500/20"
                  />
                </motion.div>
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    onClick={handleAddDestination}
                    className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white flex items-center gap-2"
                  >
                    <Plus className="w-5 h-5" />
                    Add
                  </Button>
                </motion.div>
              </div>
            </motion.div>

            {/* Destinations List */}
            <motion.div variants={itemVariants}>
              <h2 className="text-lg font-semibold text-white mb-4">
                Your Destinations ({destinations.length})
              </h2>
              {destinations.length === 0 ? (
                <motion.div
                  className="text-center py-8 text-slate-500"
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 3, repeat: Infinity }}
                >
                  <MapPin className="w-12 h-12 mx-auto mb-2 opacity-50" />
                  <p>No destinations added yet. Add your first destination above!</p>
                </motion.div>
              ) : (
                <motion.div
                  className="space-y-2"
                  variants={containerVariants}
                >
                  {destinations.map((destination, index) => (
                    <motion.div
                      key={index}
                      variants={itemVariants}
                      whileHover={{ x: 8 }}
                      className="flex items-center justify-between bg-slate-700/50 p-4 rounded-lg border border-slate-600 hover:border-slate-500 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <motion.div
                          animate={{ rotate: [0, 10, -10, 0] }}
                          transition={{ duration: 2, repeat: Infinity, delay: index * 0.1 }}
                        >
                          <MapPin className="w-5 h-5 text-orange-500" />
                        </motion.div>
                        <span className="font-medium text-white">{destination}</span>
                      </div>
                      <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.95 }}>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleRemoveDestination(index)}
                          className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </motion.div>
                    </motion.div>
                  ))}
                </motion.div>
              )}
            </motion.div>

            {/* Navigation Buttons */}
            <motion.div className="mt-8 flex gap-4" variants={itemVariants}>
              <motion.div
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="flex-1"
              >
                <Button
                  onClick={() => navigate(`/trip/${currentTrip.id}/activities`)}
                  disabled={destinations.length === 0}
                  className="w-full bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white disabled:opacity-50 font-semibold py-3 rounded-lg"
                >
                  Next: Add Activities
                </Button>
              </motion.div>
              <motion.div
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="flex-1"
              >
                <Button
                  variant="outline"
                  onClick={() => navigate("/my-trips")}
                  className="w-full border-slate-600 text-white hover:bg-slate-800 font-semibold py-3 rounded-lg"
                >
                  Cancel
                </Button>
              </motion.div>
            </motion.div>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}
