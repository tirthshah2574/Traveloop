import { Button } from "@/components/ui/button";
import { useLocation, useParams } from "wouter";
import { useApp } from "@/contexts/AppContext";
import { useEffect } from "react";
import { Compass, ArrowLeft, DollarSign, TrendingUp, AlertCircle } from "lucide-react";
import { motion } from "framer-motion";

export default function BudgetBreakdown() {
  const [, navigate] = useLocation();
  const { id } = useParams<{ id: string }>();
  const { user, trips, setCurrentTrip, currentTrip } = useApp();

  useEffect(() => {
    if (!user) {
      navigate("/login");
      return;
    }
    const trip = trips.find(t => t.id === id);
    if (trip) {
      setCurrentTrip(trip);
    }
  }, [id, trips, user, navigate, setCurrentTrip]);

  if (!currentTrip) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-900 to-slate-900 flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity }}
          className="w-8 h-8 border-4 border-orange-500 border-t-transparent rounded-full"
        />
      </div>
    );
  }

  const totalCost = currentTrip.activities.reduce((sum, a) => sum + a.cost, 0);
  const costByCategory = currentTrip.activities.reduce((acc, activity) => {
    acc[activity.category] = (acc[activity.category] || 0) + activity.cost;
    return acc;
  }, {} as Record<string, number>);

  const categories = Object.entries(costByCategory).sort((a, b) => b[1] - a[1]);
  const maxCost = Math.max(...categories.map(c => c[1]), 1);
  const remaining = (currentTrip.budget || 0) - totalCost;
  const isOverBudget = remaining < 0;

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-900 to-slate-900 text-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-slate-950/80 backdrop-blur-xl border-b border-slate-800">
        <div className="container flex items-center justify-between h-16">
          <motion.div
            className="flex items-center gap-2"
            whileHover={{ scale: 1.05 }}
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            >
              <Compass className="w-6 h-6 text-orange-500" />
            </motion.div>
            <span className="text-xl font-bold bg-gradient-to-r from-orange-500 to-pink-500 bg-clip-text text-transparent">
              Traveloop
            </span>
          </motion.div>
        </div>
      </nav>

      {/* Main Content */}
      <motion.div
        className="container py-12"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.button
          onClick={() => navigate("/my-trips")}
          className="flex items-center gap-2 text-orange-500 hover:text-orange-400 mb-8 font-medium transition-colors"
          whileHover={{ x: -5 }}
        >
          <ArrowLeft className="w-5 h-5" />
          Back to My Trips
        </motion.button>

        <div className="max-w-4xl">
          <motion.div variants={itemVariants}>
            <h1 className="text-5xl font-bold text-white mb-2">Budget Breakdown</h1>
            <p className="text-slate-400">Detailed cost analysis for {currentTrip.name}</p>
          </motion.div>

          {/* Summary Cards */}
          <motion.div
            className="grid md:grid-cols-3 gap-6 mb-8 mt-8"
            variants={containerVariants}
          >
            {[
              {
                label: "Total Cost",
                value: `$${totalCost.toLocaleString()}`,
                icon: DollarSign,
                color: "from-orange-500 to-red-500",
              },
              {
                label: "Budget",
                value: `$${(currentTrip.budget || 0).toLocaleString()}`,
                icon: TrendingUp,
                color: "from-blue-500 to-cyan-500",
              },
              {
                label: "Remaining",
                value: `$${Math.abs(remaining).toLocaleString()}`,
                icon: AlertCircle,
                color: isOverBudget ? "from-red-500 to-pink-500" : "from-green-500 to-emerald-500",
              },
            ].map((stat, index) => {
              const Icon = stat.icon;
              return (
                <motion.div
                  key={index}
                  variants={itemVariants}
                  whileHover={{ y: -8 }}
                >
                  <div className={`bg-gradient-to-br ${stat.color} p-0.5 rounded-2xl`}>
                    <div className="bg-slate-900 rounded-2xl p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-slate-400 text-sm font-medium">
                            {stat.label}
                          </p>
                          <p className={`text-3xl font-bold mt-2 ${
                            isOverBudget && stat.label === "Remaining"
                              ? "text-red-400"
                              : "text-white"
                          }`}>
                            {stat.value}
                          </p>
                        </div>
                        <motion.div
                          whileHover={{ scale: 1.1, rotate: 5 }}
                          className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} p-2.5 opacity-20`}
                        >
                          <Icon className="w-full h-full" />
                        </motion.div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </motion.div>

          {/* Over Budget Warning */}
          {isOverBudget && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-8 p-4 bg-red-500/10 border border-red-500/30 rounded-xl flex items-center gap-3"
            >
              <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0" />
              <div>
                <p className="text-red-300 font-semibold">Over Budget</p>
                <p className="text-red-200 text-sm">
                  You've exceeded your budget by ${Math.abs(remaining).toLocaleString()}
                </p>
              </div>
            </motion.div>
          )}

          {/* Cost Breakdown */}
          <motion.div
            className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl shadow-2xl border border-slate-700 p-8"
            variants={itemVariants}
          >
            <h2 className="text-2xl font-bold text-white mb-6">Cost by Category</h2>

            {categories.length === 0 ? (
              <motion.div
                className="text-center py-8 text-slate-500"
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 3, repeat: Infinity }}
              >
                <p>No activities added yet</p>
              </motion.div>
            ) : (
              <motion.div
                className="space-y-6"
                variants={containerVariants}
              >
                {categories.map(([category, cost], index) => {
                  const percentage = (cost / maxCost) * 100;
                  const percentageOfTotal = (cost / totalCost) * 100;

                  return (
                    <motion.div
                      key={category}
                      variants={itemVariants}
                      whileHover={{ x: 8 }}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-white">{category}</span>
                        <span className="text-lg font-bold bg-gradient-to-r from-orange-400 to-pink-400 bg-clip-text text-transparent">
                          ${cost.toLocaleString()} ({percentageOfTotal.toFixed(1)}%)
                        </span>
                      </div>
                      <div className="w-full bg-slate-700/50 rounded-full h-3 overflow-hidden border border-slate-600">
                        <motion.div
                          className="bg-gradient-to-r from-orange-500 to-pink-500 h-full rounded-full"
                          initial={{ width: 0 }}
                          animate={{ width: `${percentage}%` }}
                          transition={{ duration: 0.8, delay: index * 0.1 }}
                        />
                      </div>
                    </motion.div>
                  );
                })}
              </motion.div>
            )}
          </motion.div>

          {/* Navigation */}
          <motion.div className="mt-8 flex gap-4" variants={itemVariants}>
            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="flex-1"
            >
              <Button
                onClick={() => navigate(`/trip/${currentTrip.id}/itinerary`)}
                className="w-full bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white font-semibold py-3 rounded-lg"
              >
                View Itinerary
              </Button>
            </motion.div>
            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="flex-1"
            >
              <Button
                variant="outline"
                onClick={() => navigate("/my-trips")}
                className="w-full border-slate-600 text-white hover:bg-slate-800 font-semibold py-3 rounded-lg"
              >
                Done
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}
