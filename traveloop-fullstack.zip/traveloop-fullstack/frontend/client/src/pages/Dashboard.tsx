import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useApp } from "@/contexts/AppContext";
import { Compass, Plus, LogOut, MapPin, Calendar, TrendingUp, Trash2, Edit } from "lucide-react";
import { toast } from "sonner";
import { motion } from "framer-motion";
import { useState } from "react";

export default function Dashboard() {
  const [, navigate] = useLocation();
  const { user, logout, trips, deleteTrip } = useApp();
  const [hoveredTrip, setHoveredTrip] = useState<string | null>(null);

  if (!user) {
    navigate("/login");
    return null;
  }

  const upcomingTrips = trips.filter(trip => new Date(trip.startDate) > new Date());
  const totalBudget = trips.reduce((sum, trip) => sum + (trip.budget || 0), 0);
  const totalSpent = trips.reduce((sum, trip) => sum + (trip.totalCost || 0), 0);

  const handleLogout = () => {
    logout();
    toast.success("Logged out successfully");
    navigate("/");
  };

  const handleDelete = (id: string, name: string) => {
    if (window.confirm(`Are you sure you want to delete "${name}"?`)) {
      deleteTrip(id);
      toast.success("Trip deleted");
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-900 to-slate-900 text-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-slate-950/80 backdrop-blur-xl border-b border-slate-800">
        <div className="container flex items-center justify-between h-16">
          <motion.div
            className="flex items-center gap-2"
            whileHover={{ scale: 1.05 }}
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            >
              <Compass className="w-6 h-6 text-orange-500" />
            </motion.div>
            <span className="text-xl font-bold bg-gradient-to-r from-orange-500 to-pink-500 bg-clip-text text-transparent">
              Traveloop
            </span>
          </motion.div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-slate-400">Welcome, {user.name}!</span>
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button
                variant="ghost"
                onClick={handleLogout}
                className="flex items-center gap-2 text-slate-300 hover:text-white hover:bg-slate-800"
              >
                <LogOut className="w-4 h-4" />
                Logout
              </Button>
            </motion.div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <motion.div
        className="container py-12"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Header */}
        <motion.div
          className="flex items-center justify-between mb-12"
          variants={itemVariants}
        >
          <div>
            <h1 className="text-5xl font-bold text-white mb-2">Dashboard</h1>
            <p className="text-slate-400">Manage and plan your amazing trips</p>
          </div>
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button
              onClick={() => navigate("/create-trip")}
              className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white flex items-center gap-2 text-base px-6"
            >
              <Plus className="w-5 h-5" />
              Plan New Trip
            </Button>
          </motion.div>
        </motion.div>

        {/* Stats Grid */}
        <motion.div
          className="grid md:grid-cols-3 gap-6 mb-12"
          variants={containerVariants}
        >
          {[
            {
              label: "Total Trips",
              value: trips.length,
              icon: MapPin,
              color: "from-orange-500 to-red-500",
            },
            {
              label: "Upcoming Trips",
              value: upcomingTrips.length,
              icon: Calendar,
              color: "from-blue-500 to-cyan-500",
            },
            {
              label: "Total Budget",
              value: `$${totalBudget.toLocaleString()}`,
              icon: TrendingUp,
              color: "from-green-500 to-emerald-500",
            },
          ].map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={index}
                variants={itemVariants}
                whileHover={{ y: -8 }}
              >
                <div className={`bg-gradient-to-br ${stat.color} p-0.5 rounded-2xl`}>
                  <div className="bg-slate-900 rounded-2xl p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-slate-400 text-sm font-medium">
                          {stat.label}
                        </p>
                        <p className="text-3xl font-bold text-white mt-2">
                          {stat.value}
                        </p>
                      </div>
                      <motion.div
                        whileHover={{ scale: 1.1, rotate: 5 }}
                        className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} p-2.5 opacity-20`}
                      >
                        <Icon className="w-full h-full" />
                      </motion.div>
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Recent Trips */}
        <motion.div variants={itemVariants}>
          <h2 className="text-3xl font-bold text-white mb-6">Your Trips</h2>
          {trips.length === 0 ? (
            <motion.div
              className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-12 text-center border border-slate-700"
              whileHover={{ borderColor: "rgb(148, 163, 184)" }}
            >
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 3, repeat: Infinity }}
              >
                <MapPin className="w-16 h-16 text-slate-600 mx-auto mb-4" />
              </motion.div>
              <h3 className="text-lg font-semibold text-white mb-2">
                No trips yet
              </h3>
              <p className="text-slate-400 mb-6">
                Start planning your first adventure today!
              </p>
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  onClick={() => navigate("/create-trip")}
                  className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white"
                >
                  Create Your First Trip
                </Button>
              </motion.div>
            </motion.div>
          ) : (
            <motion.div
              className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
              variants={containerVariants}
            >
              {trips.map((trip, index) => (
                <motion.div
                  key={trip.id}
                  variants={itemVariants}
                  onMouseEnter={() => setHoveredTrip(trip.id)}
                  onMouseLeave={() => setHoveredTrip(null)}
                  whileHover={{ y: -8 }}
                  className="group relative"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-orange-500 to-pink-500 rounded-2xl opacity-0 group-hover:opacity-20 blur-xl transition-opacity duration-300" />
                  <div className="relative bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl overflow-hidden shadow-xl border border-slate-700 hover:border-slate-600 transition-colors">
                    {trip.coverImage && (
                      <div className="h-40 bg-gradient-to-br from-orange-400 to-blue-400 overflow-hidden relative">
                        <motion.img
                          src={trip.coverImage}
                          alt={trip.name}
                          className="w-full h-full object-cover"
                          whileHover={{ scale: 1.1 }}
                          transition={{ duration: 0.3 }}
                        />
                      </div>
                    )}
                    <div className="p-6">
                      <h3 className="text-lg font-semibold text-white mb-2">
                        {trip.name}
                      </h3>
                      <p className="text-slate-400 text-sm mb-4 line-clamp-2">
                        {trip.description}
                      </p>
                      <div className="space-y-2 text-sm mb-4">
                        <div className="flex items-center gap-2 text-slate-400">
                          <Calendar className="w-4 h-4 text-orange-500" />
                          {new Date(trip.startDate).toLocaleDateString()} -{" "}
                          {new Date(trip.endDate).toLocaleDateString()}
                        </div>
                        <div className="flex items-center gap-2 text-slate-400">
                          <MapPin className="w-4 h-4 text-orange-500" />
                          {trip.destinations.length} destination
                          {trip.destinations.length !== 1 ? "s" : ""}
                        </div>
                      </div>
                      <motion.div
                        className="flex gap-2"
                        initial={{ opacity: 0 }}
                        animate={{
                          opacity: hoveredTrip === trip.id ? 1 : 0,
                        }}
                      >
                        <motion.div
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          className="flex-1"
                        >
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => navigate(`/trip/${trip.id}/builder`)}
                            className="w-full border-slate-600 text-white hover:bg-slate-800 flex items-center justify-center gap-1"
                          >
                            <Edit className="w-4 h-4" />
                            Edit
                          </Button>
                        </motion.div>
                        <motion.div
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          className="flex-1"
                        >
                          <Button
                            size="sm"
                            onClick={() => navigate(`/trip/${trip.id}/itinerary`)}
                            className="w-full bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white"
                          >
                            View
                          </Button>
                        </motion.div>
                        <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleDelete(trip.id, trip.name)}
                            className="text-red-500 hover:text-red-400 hover:bg-red-500/10"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </motion.div>
                      </motion.div>
                      <motion.div
                        className="flex gap-2 mt-2"
                        initial={{ opacity: 1 }}
                        animate={{
                          opacity: hoveredTrip === trip.id ? 0 : 1,
                        }}
                      >
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => navigate(`/trip/${trip.id}/builder`)}
                          className="flex-1 border-slate-600 text-white hover:bg-slate-800"
                        >
                          Edit
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => navigate(`/trip/${trip.id}/itinerary`)}
                          className="flex-1 bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white"
                        >
                          View
                        </Button>
                      </motion.div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          )}
        </motion.div>
      </motion.div>
    </div>
  );
}
