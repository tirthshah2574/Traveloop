import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useLocation, useParams } from "wouter";
import { useApp } from "@/contexts/AppContext";
import { useState, useEffect } from "react";
import { Compass, ArrowLeft, Plus, Trash2, CheckCircle2, Circle } from "lucide-react";
import { toast } from "sonner";
import { motion } from "framer-motion";

const PACKING_CATEGORIES = [
  "Clothing",
  "Toiletries",
  "Electronics",
  "Documents",
  "Accessories",
  "Other",
];

export default function PackingChecklist() {
  const [, navigate] = useLocation();
  const { id } = useParams<{ id: string }>();
  const { user, trips, setCurrentTrip, currentTrip, addPackingItem, updatePackingItem, deletePackingItem } = useApp();
  const [newItem, setNewItem] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("Clothing");

  useEffect(() => {
    if (!user) {
      navigate("/login");
      return;
    }
    const trip = trips.find(t => t.id === id);
    if (trip) {
      setCurrentTrip(trip);
    }
  }, [id, trips, user, navigate, setCurrentTrip]);

  const handleAddItem = () => {
    if (!newItem.trim()) {
      toast.error("Please enter an item");
      return;
    }
    if (currentTrip) {
      addPackingItem(currentTrip.id, {
        name: newItem,
        category: selectedCategory,
        checked: false,
      });
      toast.success("Item added to packing list!");
      setNewItem("");
    }
  };

  const handleToggleItem = (itemId: string, checked: boolean) => {
    if (currentTrip) {
      updatePackingItem(currentTrip.id, itemId, { checked: !checked });
    }
  };

  const handleDeleteItem = (itemId: string) => {
    if (currentTrip) {
      deletePackingItem(currentTrip.id, itemId);
      toast.success("Item removed");
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  };

  if (!currentTrip) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-900 to-slate-900 flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity }}
          className="w-8 h-8 border-4 border-orange-500 border-t-transparent rounded-full"
        />
      </div>
    );
  }

  const itemsByCategory = currentTrip.packingItems.reduce((acc, item) => {
    if (!acc[item.category]) acc[item.category] = [];
    acc[item.category].push(item);
    return acc;
  }, {} as Record<string, typeof currentTrip.packingItems>);

  const checkedCount = currentTrip.packingItems.filter(i => i.checked).length;
  const totalCount = currentTrip.packingItems.length;
  const progressPercentage = totalCount === 0 ? 0 : (checkedCount / totalCount) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-900 to-slate-900 text-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-slate-950/80 backdrop-blur-xl border-b border-slate-800">
        <div className="container flex items-center justify-between h-16">
          <motion.div
            className="flex items-center gap-2"
            whileHover={{ scale: 1.05 }}
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            >
              <Compass className="w-6 h-6 text-orange-500" />
            </motion.div>
            <span className="text-xl font-bold bg-gradient-to-r from-orange-500 to-pink-500 bg-clip-text text-transparent">
              Traveloop
            </span>
          </motion.div>
        </div>
      </nav>

      {/* Main Content */}
      <motion.div
        className="container py-12"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.button
          onClick={() => navigate("/my-trips")}
          className="flex items-center gap-2 text-orange-500 hover:text-orange-400 mb-8 font-medium transition-colors"
          whileHover={{ x: -5 }}
        >
          <ArrowLeft className="w-5 h-5" />
          Back to My Trips
        </motion.button>

        <div className="max-w-3xl">
          <motion.div variants={itemVariants}>
            <h1 className="text-5xl font-bold text-white mb-2">Packing Checklist</h1>
            <p className="text-slate-400">Prepare for your {currentTrip.name}</p>
          </motion.div>

          {/* Progress */}
          {totalCount > 0 && (
            <motion.div
              className="mt-8 bg-gradient-to-br from-slate-800 to-slate-900 rounded-xl p-6 shadow-lg border border-slate-700"
              variants={itemVariants}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="font-medium text-white">Packing Progress</span>
                <span className="text-sm font-semibold bg-gradient-to-r from-orange-400 to-pink-400 bg-clip-text text-transparent">
                  {checkedCount} of {totalCount} items
                </span>
              </div>
              <div className="w-full bg-slate-700/50 rounded-full h-3 overflow-hidden border border-slate-600">
                <motion.div
                  className="bg-gradient-to-r from-orange-500 to-pink-500 h-full rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${progressPercentage}%` }}
                  transition={{ duration: 0.8 }}
                />
              </div>
            </motion.div>
          )}

          {/* Add Item */}
          <motion.div
            className="mt-8 bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl shadow-2xl border border-slate-700 p-8 backdrop-blur-xl"
            variants={itemVariants}
          >
            <h2 className="text-lg font-semibold text-white mb-4">Add Items</h2>
            <motion.div className="space-y-4" variants={containerVariants}>
              <motion.div variants={itemVariants}>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Category
                </label>
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full px-4 py-2 bg-slate-700/50 border border-slate-600 text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500"
                >
                  {PACKING_CATEGORIES.map(cat => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </motion.div>
              <motion.div variants={itemVariants} className="flex gap-2">
                <Input
                  type="text"
                  placeholder="e.g., Passport, Sunscreen, Charger"
                  value={newItem}
                  onChange={(e) => setNewItem(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && handleAddItem()}
                  className="bg-slate-700/50 border-slate-600 text-white placeholder-slate-500 focus:border-orange-500 focus:ring-orange-500/20"
                />
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    onClick={handleAddItem}
                    className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white flex items-center gap-2"
                  >
                    <Plus className="w-5 h-5" />
                    Add
                  </Button>
                </motion.div>
              </motion.div>
            </motion.div>
          </motion.div>

          {/* Items List */}
          <motion.div
            className="mt-8 bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl shadow-2xl border border-slate-700 p-8 backdrop-blur-xl"
            variants={itemVariants}
          >
            <h2 className="text-lg font-semibold text-white mb-6">
              My Packing List ({totalCount})
            </h2>

            {totalCount === 0 ? (
              <motion.div
                className="text-center py-8 text-slate-500"
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 3, repeat: Infinity }}
              >
                <p>No items yet. Start adding items to your packing list!</p>
              </motion.div>
            ) : (
              <motion.div className="space-y-6" variants={containerVariants}>
                {PACKING_CATEGORIES.map(category => {
                  const items = itemsByCategory[category] || [];
                  if (items.length === 0) return null;

                  return (
                    <motion.div key={category} variants={itemVariants}>
                      <h3 className="font-semibold text-white mb-3 text-sm uppercase tracking-wide">
                        {category}
                      </h3>
                      <motion.div className="space-y-2" variants={containerVariants}>
                        {items.map(item => (
                          <motion.div
                            key={item.id}
                            variants={itemVariants}
                            whileHover={{ x: 8 }}
                            className="flex items-center gap-3 p-3 bg-slate-700/50 rounded-lg border border-slate-600 hover:border-slate-500 transition-colors"
                          >
                            <motion.button
                              onClick={() => handleToggleItem(item.id, item.checked)}
                              className="flex-shrink-0 text-orange-500 hover:text-orange-400"
                              whileHover={{ scale: 1.1 }}
                              whileTap={{ scale: 0.95 }}
                            >
                              {item.checked ? (
                                <CheckCircle2 className="w-6 h-6" />
                              ) : (
                                <Circle className="w-6 h-6" />
                              )}
                            </motion.button>
                            <span
                              className={`flex-1 ${
                                item.checked
                                  ? "line-through text-slate-500"
                                  : "text-white"
                              }`}
                            >
                              {item.name}
                            </span>
                            <motion.div
                              whileHover={{ scale: 1.1 }}
                              whileTap={{ scale: 0.95 }}
                            >
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => handleDeleteItem(item.id)}
                                className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </motion.div>
                          </motion.div>
                        ))}
                      </motion.div>
                    </motion.div>
                  );
                })}
              </motion.div>
            )}
          </motion.div>

          {/* Navigation */}
          <motion.div className="mt-8 flex gap-4" variants={itemVariants}>
            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="flex-1"
            >
              <Button
                onClick={() => navigate(`/trip/${currentTrip.id}/itinerary`)}
                className="w-full bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white font-semibold py-3 rounded-lg"
              >
                View Itinerary
              </Button>
            </motion.div>
            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="flex-1"
            >
              <Button
                variant="outline"
                onClick={() => navigate("/my-trips")}
                className="w-full border-slate-600 text-white hover:bg-slate-800 font-semibold py-3 rounded-lg"
              >
                Done
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}
