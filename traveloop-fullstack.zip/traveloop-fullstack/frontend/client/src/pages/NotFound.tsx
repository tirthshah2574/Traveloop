import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { Compass, ArrowLeft } from "lucide-react";

export default function NotFound() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-blue-50 flex items-center justify-center">
      <div className="text-center">
        <div className="flex items-center justify-center gap-2 mb-8">
          <Compass className="w-8 h-8 text-orange-600" />
          <span className="text-2xl font-bold text-gray-900">Traveloop</span>
        </div>
        <h1 className="text-6xl font-bold text-gray-900 mb-4">404</h1>
        <p className="text-xl text-gray-600 mb-8">
          Oops! The page you're looking for doesn't exist.
        </p>
        <Button
          onClick={() => navigate("/")}
          className="bg-orange-600 hover:bg-orange-700 text-white flex items-center gap-2 mx-auto"
        >
          <ArrowLeft className="w-5 h-5" />
          Go Home
        </Button>
      </div>
    </div>
  );
}
