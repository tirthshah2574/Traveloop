// Lightweight fetch wrapper around the Traveloop backend.
// Base URL is read from VITE_API_URL (defaults to http://localhost:4000/api).

const BASE_URL =
  (import.meta.env.VITE_API_URL as string | undefined) ||
  'http://localhost:4000/api';

const TOKEN_KEY = 'traveloop_token';

export const tokenStore = {
  get: () => (typeof localStorage !== 'undefined' ? localStorage.getItem(TOKEN_KEY) : null),
  set: (t: string) => localStorage.setItem(TOKEN_KEY, t),
  clear: () => localStorage.removeItem(TOKEN_KEY),
};

async function request<T>(
  path: string,
  options: RequestInit & { json?: unknown } = {}
): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string> | undefined),
  };
  const token = tokenStore.get();
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await fetch(`${BASE_URL}${path}`, {
    ...options,
    headers,
    body: options.json !== undefined ? JSON.stringify(options.json) : options.body,
  });

  if (res.status === 204) return undefined as T;

  const text = await res.text();
  const data = text ? JSON.parse(text) : null;

  if (!res.ok) {
    const msg = (data && (data.error || data.message)) || `Request failed (${res.status})`;
    throw new Error(msg);
  }
  return data as T;
}

export const api = {
  get:    <T>(p: string)              => request<T>(p),
  post:   <T>(p: string, json?: any)  => request<T>(p, { method: 'POST', json }),
  patch:  <T>(p: string, json?: any)  => request<T>(p, { method: 'PATCH', json }),
  del:    <T>(p: string)              => request<T>(p, { method: 'DELETE' }),
};
