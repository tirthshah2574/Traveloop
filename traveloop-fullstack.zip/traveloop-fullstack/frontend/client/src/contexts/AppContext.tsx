import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { api, tokenStore } from '@/lib/api';

export interface Trip {
  id: string;
  name: string;
  description: string;
  startDate: string;
  endDate: string;
  destinations: string[];
  coverImage?: string | null;
  budget?: number | null;
  totalCost?: number;
  activities: Activity[];
  packingItems: PackingItem[];
}

export interface Activity {
  id: string;
  tripId: string;
  city: string;
  name: string;
  description: string;
  date: string;
  duration: number;
  cost: number;
  category: string;
  image?: string | null;
}

export interface PackingItem {
  id: string;
  tripId: string;
  name: string;
  checked: boolean;
  category: string;
}

export interface User {
  id: string;
  email: string;
  name: string;
}

interface AppContextType {
  user: User | null;
  trips: Trip[];
  currentTrip: Trip | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  signup: (email: string, password: string, name: string) => Promise<void>;
  logout: () => void;
  refreshTrips: () => Promise<void>;
  loadTrip: (id: string) => Promise<Trip | null>;
  createTrip: (trip: Omit<Trip, 'id' | 'activities' | 'packingItems' | 'destinations'>) => Promise<Trip>;
  updateTrip: (id: string, trip: Partial<Trip>) => Promise<void>;
  deleteTrip: (id: string) => Promise<void>;
  setCurrentTrip: (trip: Trip | null) => void;
  addActivity: (tripId: string, activity: Omit<Activity, 'id' | 'tripId'>) => Promise<void>;
  updateActivity: (tripId: string, activityId: string, activity: Partial<Activity>) => Promise<void>;
  deleteActivity: (tripId: string, activityId: string) => Promise<void>;
  addPackingItem: (tripId: string, item: Omit<PackingItem, 'id' | 'tripId'>) => Promise<void>;
  updatePackingItem: (tripId: string, itemId: string, item: Partial<PackingItem>) => Promise<void>;
  deletePackingItem: (tripId: string, itemId: string) => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// --- helpers to map server payloads ---
const mapTrip = (t: any): Trip => ({
  id: t.id,
  name: t.name,
  description: t.description ?? '',
  startDate: t.startDate,
  endDate: t.endDate,
  destinations: t.destinations ?? [],
  coverImage: t.coverImage ?? null,
  budget: t.budget ?? null,
  totalCost: t.totalCost ?? 0,
  activities: t.activities ?? [],
  packingItems: t.packingItems ?? [],
});

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [trips, setTrips] = useState<Trip[]>([]);
  const [currentTrip, setCurrentTrip] = useState<Trip | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Restore session on mount
  useEffect(() => {
    const token = tokenStore.get();
    if (!token) return;
    (async () => {
      try {
        const { user } = await api.get<{ user: User }>('/auth/me');
        setUser(user);
        const { trips } = await api.get<{ trips: any[] }>('/trips');
        setTrips(trips.map(mapTrip));
      } catch {
        tokenStore.clear();
      }
    })();
  }, []);

  const refreshTrips = useCallback(async () => {
    const { trips } = await api.get<{ trips: any[] }>('/trips');
    setTrips(trips.map(mapTrip));
  }, []);

  const loadTrip = useCallback(async (id: string) => {
    const { trip } = await api.get<{ trip: any }>(`/trips/${id}`);
    const mapped = mapTrip(trip);
    setCurrentTrip(mapped);
    return mapped;
  }, []);

  const login = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      const { token, user } = await api.post<{ token: string; user: User }>('/auth/login', { email, password });
      tokenStore.set(token);
      setUser(user);
      await refreshTrips();
    } finally { setIsLoading(false); }
  };

  const signup = async (email: string, password: string, name: string) => {
    setIsLoading(true);
    try {
      const { token, user } = await api.post<{ token: string; user: User }>('/auth/signup', { email, password, name });
      tokenStore.set(token);
      setUser(user);
      setTrips([]);
    } finally { setIsLoading(false); }
  };

  const logout = () => {
    tokenStore.clear();
    setUser(null);
    setTrips([]);
    setCurrentTrip(null);
  };

  const createTrip: AppContextType['createTrip'] = async (data) => {
    const { trip } = await api.post<{ trip: any }>('/trips', {
      name: data.name,
      description: data.description,
      startDate: data.startDate,
      endDate: data.endDate,
      coverImage: data.coverImage ?? null,
      budget: data.budget ?? null,
    });
    const mapped = mapTrip(trip);
    setTrips((prev) => [mapped, ...prev]);
    return mapped;
  };

  const updateTrip = async (id: string, data: Partial<Trip>) => {
    const payload: any = {};
    for (const k of ['name','description','startDate','endDate','coverImage','budget'] as const) {
      if ((data as any)[k] !== undefined) payload[k] = (data as any)[k];
    }
    const { trip } = await api.patch<{ trip: any }>(`/trips/${id}`, payload);
    const mapped = mapTrip(trip);
    setTrips((prev) => prev.map((t) => (t.id === id ? { ...t, ...mapped } : t)));
    if (currentTrip?.id === id) setCurrentTrip({ ...currentTrip, ...mapped });
  };

  const deleteTrip = async (id: string) => {
    await api.del(`/trips/${id}`);
    setTrips((prev) => prev.filter((t) => t.id !== id));
    if (currentTrip?.id === id) setCurrentTrip(null);
  };

  const addActivity: AppContextType['addActivity'] = async (tripId, a) => {
    const { activity } = await api.post<{ activity: Activity }>(`/trips/${tripId}/activities`, a);
    setCurrentTrip((c) => (c && c.id === tripId ? { ...c, activities: [...c.activities, activity] } : c));
  };

  const updateActivity: AppContextType['updateActivity'] = async (tripId, activityId, a) => {
    const { activity } = await api.patch<{ activity: Activity }>(`/trips/${tripId}/activities/${activityId}`, a);
    setCurrentTrip((c) =>
      c && c.id === tripId
        ? { ...c, activities: c.activities.map((x) => (x.id === activityId ? activity : x)) }
        : c
    );
  };

  const deleteActivity: AppContextType['deleteActivity'] = async (tripId, activityId) => {
    await api.del(`/trips/${tripId}/activities/${activityId}`);
    setCurrentTrip((c) =>
      c && c.id === tripId
        ? { ...c, activities: c.activities.filter((x) => x.id !== activityId) }
        : c
    );
  };

  const addPackingItem: AppContextType['addPackingItem'] = async (tripId, item) => {
    const { item: created } = await api.post<{ item: PackingItem }>(`/trips/${tripId}/packing`, item);
    setCurrentTrip((c) => (c && c.id === tripId ? { ...c, packingItems: [...c.packingItems, created] } : c));
  };

  const updatePackingItem: AppContextType['updatePackingItem'] = async (tripId, itemId, item) => {
    const { item: updated } = await api.patch<{ item: PackingItem }>(`/trips/${tripId}/packing/${itemId}`, item);
    setCurrentTrip((c) =>
      c && c.id === tripId
        ? { ...c, packingItems: c.packingItems.map((x) => (x.id === itemId ? updated : x)) }
        : c
    );
  };

  const deletePackingItem: AppContextType['deletePackingItem'] = async (tripId, itemId) => {
    await api.del(`/trips/${tripId}/packing/${itemId}`);
    setCurrentTrip((c) =>
      c && c.id === tripId
        ? { ...c, packingItems: c.packingItems.filter((x) => x.id !== itemId) }
        : c
    );
  };

  return (
    <AppContext.Provider
      value={{
        user, trips, currentTrip, isLoading,
        login, signup, logout,
        refreshTrips, loadTrip,
        createTrip, updateTrip, deleteTrip, setCurrentTrip,
        addActivity, updateActivity, deleteActivity,
        addPackingItem, updatePackingItem, deletePackingItem,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
};
