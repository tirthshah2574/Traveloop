import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { Compass, ArrowLeft } from "lucide-react";

export default function CitySearch() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-blue-50">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-200">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <Compass className="w-6 h-6 text-orange-600" />
            <span className="text-xl font-bold text-gray-900">Traveloop</span>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="container py-12">
        <button
          onClick={() => navigate("/my-trips")}
          className="flex items-center gap-2 text-orange-600 hover:text-orange-700 mb-8 font-medium"
        >
          <ArrowLeft className="w-5 h-5" />
          Back
        </button>

        <div className="max-w-2xl">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">City Search</h1>
          <p className="text-gray-600 mb-8">
            This feature is coming soon. Use the Itinerary Builder to add destinations.
          </p>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
            <p className="text-gray-600 mb-6">
              Advanced city search with recommendations and details will be available soon.
            </p>
            <Button
              onClick={() => navigate("/my-trips")}
              className="bg-orange-600 hover:bg-orange-700 text-white"
            >
              Go Back
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
